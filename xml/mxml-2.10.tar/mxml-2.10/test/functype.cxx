typedef int (*foo_func_t)(void *foo, int bar);	/**** Foo function type ****/
