typedef int foo_simple_t;		/* Simple integer type */

typedef int foo_simple_private_t;	/* @private@ */
